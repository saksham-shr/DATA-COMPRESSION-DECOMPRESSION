Installation Guide

1.Install java run time enviroment
2.run wingph.jre


jre installation file is available in c:/program files/WinGph