/*
 * huffmanSignature.java
 *
 * Created on May 12, 2009, 11:50 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package CHuffmanCompressor;

/**
 *
 * @author admin
 */
public interface huffmanSignature {
    	final String hSignature = "SHE";
	final int MAXCHARS = 256;
	final String strExtension = ".huf";

    
}
